package com.converter;

import com.bean.CustomerBean;
import com.entity.Customer;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;
import jakarta.inject.Inject;

@FacesConverter(value = "customerConverter", managed = true)
public class CustomerConverter implements Converter<Customer> {

    @Inject
    private CustomerBean customerBean;

    @Override
    public Customer getAsObject(FacesContext context, UIComponent component, String value) {
        if (value == null || value.isEmpty()) return null;
        return customerBean.findById(Integer.parseInt(value));
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Customer customer) {
        if (customer == null) return "";
        return String.valueOf(customer.getId());
    }
}
