package com.bean;

import com.entity.Customer;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

import java.io.Serializable;
import java.util.List;

@Named
@SessionScoped
public class CustomerBean implements Serializable {

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    private Customer customer = new Customer();
    private List<Customer> customerList;

    @PostConstruct
    public void init() {
        loadCustomers();
    }

    public void loadCustomers() {
        customerList = em.createNamedQuery("Customer.findAll", Customer.class).getResultList();
    }

    @Transactional
    public String save() {
        if (customer.getId() == null) {
            em.persist(customer);
        } else {
            em.merge(customer);
        }
        loadCustomers();
        customer = new Customer();
        return null;
    }

    @Transactional
    public String delete(Customer c) {
        Customer toDelete = em.find(Customer.class, c.getId());
        if (toDelete != null) {
            em.remove(toDelete);
        }
        loadCustomers();
        return null;
    }

    public String edit(Customer c) {
        this.customer = c;
        return null;
    }

    // Getters and Setters
    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<Customer> getCustomerList() {
        return customerList;
    }

    public void setCustomerList(List<Customer> customerList) {
        this.customerList = customerList;
    }
    public void resetCustomer() {
    this.customer = new Customer();
}
    public Customer findById(int id) {
    return em.find(Customer.class, id);
}
}
