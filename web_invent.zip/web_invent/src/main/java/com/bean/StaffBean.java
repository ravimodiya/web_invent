package com.bean;

import com.ejb.StaffFacade;
import com.entity.Staff;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.transaction.Transactional;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Named
@SessionScoped
public class StaffBean implements Serializable {

    @Inject
    private StaffFacade staffFacade;

    private Staff newStaff;
    private List<Staff> staffList;

    @PostConstruct
    public void init() {
        newStaff = new Staff();
        loadStaffList();
    }

    private void loadStaffList() {
        staffList = staffFacade.findAll();
    }

    @Transactional
    public void saveStaff() {
        staffFacade.create(newStaff);
        newStaff = new Staff();
        loadStaffList();
    }

    @Transactional
    public void updateStaff(Staff staff) {
        staff.setEditable(false);
        staffFacade.update(staff);
        loadStaffList();
    }

    public void editStaff(Staff staff) {
        staff.setEditable(true);
    }

    @Transactional
    public void deleteStaff(Staff staff) {
        staffFacade.delete(staff);
        loadStaffList();
    }

    public void cancelEdit(Staff staff) {
        staff.setEditable(false);
        loadStaffList();
    }

    // Getters and Setters
    public Staff getNewStaff() {
        return newStaff;
    }

    public void setNewStaff(Staff newStaff) {
        this.newStaff = newStaff;
    }

    public List<Staff> getStaffList() {
        return staffList;
    }

    public void setStaffList(List<Staff> staffList) {
        this.staffList = staffList;
    }
}
