package com.bean;

import com.ejb.OrdersFacade;
import com.entity.Customer;
import com.entity.OrderDetail;
import com.entity.Orders;
import com.entity.Product;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Named
@SessionScoped
public class OrderBean implements Serializable {

    @Inject
    private OrdersFacade ordersFacade;

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    private Orders currentOrder;
    private List<OrderDetail> orderDetails = new ArrayList<>();

    private Customer selectedCustomer;
    private Product selectedProduct;
    private int quantity;
    private String status;

    private List<Customer> customerList;
    private List<Product> productList;
    private List<Orders> orderList;

    @PostConstruct
    public void init() {
        currentOrder = new Orders();
        customerList = em.createNamedQuery("Customer.findAll", Customer.class).getResultList();
        productList = em.createNamedQuery("Product.findAll", Product.class).getResultList();
        refreshOrderList();
    }

    public void addProductToOrder() {
        if (selectedProduct != null && quantity > 0) {
            OrderDetail detail = new OrderDetail();
            detail.setProductId(selectedProduct);
            detail.setQuantity(quantity);
            detail.setPrice(selectedProduct.getPrice() * quantity);
            orderDetails.add(detail);
            selectedProduct = null;
            quantity = 0;
        }
    }

    public String saveOrder() {
        currentOrder.setOrderDate(new Date());
        currentOrder.setCustid(selectedCustomer);

        ordersFacade.saveOrderWithDetails(currentOrder, orderDetails);
refreshOrderList();
        // Reset form
        currentOrder = new Orders();
        orderDetails = new ArrayList<>();
        selectedCustomer = null;

        // Refresh order list after save
        refreshOrderList();

        return "order.xhtml?faces-redirect=true";
    }

    private void refreshOrderList() {
        orderList = ordersFacade.findAll();
        // Force lazy loading of order details
        for (Orders o : orderList) {
            o.getOrderDetailCollection().size();
        }
    }
@Transactional
public void updateStatus(Orders order) {
    Orders managed = em.find(Orders.class, order.getId());
    if (managed != null) {
        managed.setStatus(order.getStatus());
        em.merge(managed);
    }
}
public List<Product> searchProducts(String query) {
    return em.createQuery("SELECT p FROM Product p WHERE LOWER(p.name) LIKE :q", Product.class)
             .setParameter("q", "%" + query.toLowerCase() + "%")
             .getResultList();
}
public void updateOrderStatus(Orders order) {
    ordersFacade.updateOrderStatus(order);  // calls EJB method with transaction
    refreshOrderList(); // optional: refresh to see updates
}
    public List<Orders> getOrderList() {
        return orderList;
    }

    public double calculateTotal(Orders order) {
        double total = 0;
        for (OrderDetail detail : order.getOrderDetailCollection()) {
            total += detail.getPrice();
        }
        return total;
    }

    public double getOrderTotal() {
        double total = 0;
        for (OrderDetail detail : orderDetails) {
            total += detail.getPrice();
        }
        return total;
    }

    // Getters and setters
    public Orders getCurrentOrder() {
        return currentOrder;
    }

    public List<OrderDetail> getOrderDetails() {
        return orderDetails;
    }

    public Customer getSelectedCustomer() {
        return selectedCustomer;
    }

    public void setSelectedCustomer(Customer selectedCustomer) {
        this.selectedCustomer = selectedCustomer;
    }

    public Product getSelectedProduct() {
        return selectedProduct;
    }

    public void setSelectedProduct(Product selectedProduct) {
        this.selectedProduct = selectedProduct;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public List<Customer> getCustomerList() {
        return customerList;
    }

    public List<Product> getProductList() {
        return productList;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
