package com.bean;

import com.entity.Category;
import com.entity.Product;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Inject;

import java.io.Serializable;
import java.util.List;

@Named
@SessionScoped

public class ProductBean implements Serializable {

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    private Product product = new Product();
    private List<Product> productList;
private String searchTerm = "";

@Inject
private CategoryBean categoryBean;

public List<Category> getCategories() {
    return categoryBean.getCategoryList();
}
    @PostConstruct
    public void init() {
        loadProducts();
    }

    public void loadProducts() {
        productList = em.createNamedQuery("Product.findAll", Product.class).getResultList();
    }

    @Transactional
    public String save() {
        try {
            if (product.getId() == null) {
                em.persist(product);
                FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage("Product added successfully."));
            } else {
                em.merge(product);
                FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage("Product updated successfully."));
            }
            loadProducts(); // Refresh list
            product = new Product(); // Reset form
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error saving product.", null));
        }
        return null;
    }

    @Transactional
    public String delete(Product p) {
        try {
            Product toDelete = em.find(Product.class, p.getId());
            if (toDelete != null) {
                em.remove(toDelete);
                FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage("Product deleted successfully."));
            }
            loadProducts();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error deleting product.", null));
        }
        return null;
    }

    public String edit(Product p) {
        // Reload from DB to avoid reference issues
        this.product = em.find(Product.class, p.getId());
        return null;
    }
public void search() {
    if (searchTerm == null || searchTerm.trim().isEmpty()) {
        loadProducts();
    } else {
        productList = em.createQuery("SELECT p FROM Product p WHERE LOWER(p.name) LIKE :search", Product.class)
                        .setParameter("search", "%" + searchTerm.toLowerCase() + "%")
                        .getResultList();
    }
}

    // Reset product manually
    public String reset() {
        this.product = new Product();
        return null;
    }

    // Getters and Setters
    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public List<Product> getProductList() {
        return productList;
    }

    public void setProductList(List<Product> productList) {
        this.productList = productList;
    }
    public String getSearchTerm() {
    return searchTerm;
}

public void setSearchTerm(String searchTerm) {
    this.searchTerm = searchTerm;
}
public Product findById(int id) {
    return em.find(Product.class, id);
}
}
