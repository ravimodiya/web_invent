package com.bean;

import com.entity.Staff;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.io.Serializable;
import java.util.List;

@Named
@SessionScoped
public class LoginBean implements Serializable {

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    private String email;
    private String password;
    private Staff loggedInStaff;

public String login() {
        try {
            Staff staff = em.createQuery("SELECT s FROM Staff s WHERE s.email = :email AND s.password = :password", Staff.class)
                    .setParameter("email", email)
                    .setParameter("password", password)
                    .getSingleResult();

            if (staff != null) {
                this.loggedInStaff = staff;

                if ("admin".equalsIgnoreCase(staff.getRole())) {
                    FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("loginBean", this);

                    return "product.xhtml?faces-redirect=true";
                } else {
                    FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("loginBean", this);

                    return "employee/dashboard.xhtml?faces-redirect=true";
                }
            }
        
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Login Failed", "Invalid email or password"));
            return null;
        }
        return "product.xhtml?faces-redirect=true";
         //return "login.xhtml?faces-redirect=true";
}
    public String logout() {
        loggedInStaff = null;
        email = null;
        password = null;
        return "login.xhtml?faces-redirect=true";
    }

    public boolean isLoggedIn() {
        return loggedInStaff != null;
    }

    // Getters & Setters

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Staff getLoggedInStaff() {
        return loggedInStaff;
    }

    public void setLoggedInStaff(Staff loggedInStaff) {
        this.loggedInStaff = loggedInStaff;
    }

}