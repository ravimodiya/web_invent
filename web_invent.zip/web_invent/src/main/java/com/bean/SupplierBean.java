package com.bean;

import com.entity.Supplier;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

import java.io.Serializable;
import java.util.List;

@Named
@SessionScoped
public class SupplierBean implements Serializable {

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    private Supplier newSupplier;
    private Supplier selectedSupplier;
    private List<Supplier> supplierList;

    @PostConstruct
    public void init() {
        newSupplier = new Supplier();
        loadSuppliers();
    }

    public void loadSuppliers() {
        supplierList = em.createNamedQuery("Supplier.findAll", Supplier.class).getResultList();
    }

    @Transactional
    public void addSupplier() {
        em.persist(newSupplier);
        loadSuppliers(); // Refresh list
        newSupplier = new Supplier(); // Reset form
    }

    @Transactional
    public void updateSupplier() {
        em.merge(selectedSupplier);
        loadSuppliers();
    }

    @Transactional
    public void deleteSupplier(Supplier supplier) {
        Supplier toRemove = em.find(Supplier.class, supplier.getId());
        if (toRemove != null) {
            em.remove(toRemove);
            loadSuppliers();
        }
    }

    // Getters and Setters
    public Supplier getNewSupplier() {
        return newSupplier;
    }

    public void setNewSupplier(Supplier newSupplier) {
        this.newSupplier = newSupplier;
    }

    public Supplier getSelectedSupplier() {
        return selectedSupplier;
    }

    public void setSelectedSupplier(Supplier selectedSupplier) {
        this.selectedSupplier = selectedSupplier;
    }

    public List<Supplier> getSupplierList() {
        return supplierList;
    }
}
