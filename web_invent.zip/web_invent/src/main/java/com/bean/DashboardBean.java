package com.bean;

import com.entity.Product;
import com.entity.Customer;
import com.entity.Orders;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

@Named
@RequestScoped
public class DashboardBean implements Serializable {

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    private int totalProducts;
    private int totalOrders;
    private int totalCustomers;

    private List<Product> lowStockProducts;

    private String chartLabels; // For monthly bar chart
    private String chartData;

    private String statusLabels; // For pie chart
    private String statusData;

    @PostConstruct
    public void init() {
        // 1. Count totals
        totalProducts = ((Long) em.createQuery("SELECT COUNT(p) FROM Product p").getSingleResult()).intValue();
        totalOrders = ((Long) em.createQuery("SELECT COUNT(o) FROM Orders o").getSingleResult()).intValue();
        totalCustomers = ((Long) em.createQuery("SELECT COUNT(c) FROM Customer c").getSingleResult()).intValue();

        // 2. Low stock alert
        lowStockProducts = em.createQuery("SELECT p FROM Product p WHERE p.quantity < 10", Product.class)
                             .getResultList();

        // 3. Orders by month (bar chart)
        List<Object[]> monthlyResults = em.createQuery(
            "SELECT FUNCTION('MONTH', o.orderDate), COUNT(o) FROM Orders o GROUP BY FUNCTION('MONTH', o.orderDate)",
            Object[].class
        ).getResultList();

        Map<String, Long> ordersPerMonth = new LinkedHashMap<>();
        for (Object[] row : monthlyResults) {
            int month = (int) row[0];
            long count = (long) row[1];
            ordersPerMonth.put(getMonthName(month), count);
        }

        chartLabels = ordersPerMonth.keySet().stream()
                .map(label -> "\"" + label + "\"")
                .collect(Collectors.joining(", "));
        chartData = ordersPerMonth.values().stream()
                .map(String::valueOf)
                .collect(Collectors.joining(", "));

        // 4. Orders by status (pie chart)
        List<Object[]> statusResults = em.createQuery(
        "SELECT o.status, COUNT(o) FROM Orders o GROUP BY o.status", Object[].class
    ).getResultList();

    Map<String, Long> statusMap = new LinkedHashMap<>();
    for (Object[] row : statusResults) {
        String status = (String) row[0];
        long count = (long) row[1];
        statusMap.put(status, count);
    }

    statusLabels = statusMap.keySet().stream()
            .map(label -> "\"" + label + "\"")
            .collect(Collectors.joining(", "));

    statusData = statusMap.values().stream()
            .map(String::valueOf)
            .collect(Collectors.joining(", "));
}


    private String getMonthName(int month) {
        switch (month) {
            case 1: return "Jan";
            case 2: return "Feb";
            case 3: return "Mar";
            case 4: return "Apr";
            case 5: return "May";
            case 6: return "Jun";
            case 7: return "Jul";
            case 8: return "Aug";
            case 9: return "Sep";
            case 10: return "Oct";
            case 11: return "Nov";
            case 12: return "Dec";
            default: return "Unknown";
        }
    }

    // === Getters ===
    public int getTotalProducts() {
        return totalProducts;
    }

    public int getTotalOrders() {
        return totalOrders;
    }

    public int getTotalCustomers() {
        return totalCustomers;
    }

    public List<Product> getLowStockProducts() {
        return lowStockProducts;
    }

    public String getChartLabels() {
        return chartLabels;
    }

    public String getChartData() {
        return chartData;
    }

    public String getStatusLabels() {
        return statusLabels;
    }

    public String getStatusData() {
        return statusData;
    }
}
