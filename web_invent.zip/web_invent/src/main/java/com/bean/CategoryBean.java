package com.bean;

import com.entity.Category;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

import java.io.Serializable;
import java.util.List;

@Named
@SessionScoped
public class CategoryBean implements Serializable {

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    private Category category = new Category();
    private List<Category> categoryList;

    @PostConstruct
    public void init() {
        loadCategories();
    }

    public void loadCategories() {
        categoryList = em.createNamedQuery("Category.findAll", Category.class).getResultList();
    }

    @Transactional
    public String save() {
        if (category.getId() == null) {
            em.persist(category);
        } else {
            em.merge(category);
        }
        loadCategories();
        category = new Category(); // Reset form
        return null;
    }

    @Transactional
    public String delete(Category c) {
        Category toDelete = em.find(Category.class, c.getId());
        if (toDelete != null) {
            em.remove(toDelete);
        }
        loadCategories();
        return null;
    }

    public String edit(Category c) {
        this.category = c;
        return null;
    }
public Category findById(int id) {
    return em.find(Category.class, id);
}
    // Getters and setters
    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public List<Category> getCategoryList() {
        return categoryList;
    }

    public void setCategoryList(List<Category> categoryList) {
        this.categoryList = categoryList;
    }

}

