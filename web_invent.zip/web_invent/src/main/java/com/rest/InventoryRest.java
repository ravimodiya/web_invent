package com.rest;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Stateless
@Path("/inventory")
public class InventoryRest {

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    @GET
    @Path("/total-value")
    @Produces(MediaType.TEXT_PLAIN)
    public String getTotalInventoryValue() {
        Double total = em.createQuery("SELECT SUM(p.price * p.quantity) FROM Product p", Double.class)
                         .getSingleResult();
        return String.format("₹ %.2f", total != null ? total : 0.0);
    }
}
