package com.ejb;

import com.entity.Staff;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class StaffFacade {

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    public void create(Staff staff) {
        em.persist(staff);
    }

    public void update(Staff staff) {
        em.merge(staff);
    }

    public void delete(Staff staff) {
        em.remove(em.merge(staff));
    }

    public Staff find(Object id) {
        return em.find(Staff.class, id);
    }

    public List<Staff> findAll() {
        return em.createNamedQuery("Staff.findAll", Staff.class).getResultList();
    }
}
