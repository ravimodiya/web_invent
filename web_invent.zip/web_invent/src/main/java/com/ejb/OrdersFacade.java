package com.ejb;

import com.entity.Orders;
import com.entity.OrderDetail;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class OrdersFacade {
    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    public void saveOrderWithDetails(Orders order, List<OrderDetail> details) {
        em.persist(order);
        for (OrderDetail d : details) {
            d.setOrderId(order);
            em.persist(d);
        }
        em.flush();
        em.refresh(order);
    }


    public void updateOrderStatus(Orders order) {
        Orders managed = em.find(Orders.class, order.getId());
        if (managed != null) {
            managed.setStatus(order.getStatus());
            em.merge(managed);
        }
    
} 

    public List<Orders> findAll() {
        return em.createNamedQuery("Orders.findAll", Orders.class).getResultList();
    }
}
